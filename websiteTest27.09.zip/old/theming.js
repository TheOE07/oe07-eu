var r = document.querySelector(":root");

var backgrounds = [
    "assets/blueGradient.jpg",
    "assets/leavesGreen.jpg",
    "assets/lightPinkTexturedBackground.GIF",
]

var themes = [
    {
        name: "blue",
        background: "assets/WaterTileOcean.gif",
        textColour: "#ffffff",
        linkColour: "rgb(0, 84, 126)",
        mainBackgroundColour: "#76bfff",
        sidebarBackgroundColour: "#4da6ff",
    },
    {
        name: "green",
        background: "assets/leavesGreen.jpg",
        textColour: "#ffffff",
        linkColour: "#77ff89",
        mainBackgroundColour: "#519951",
        sidebarBackgroundColour: "#48ba48",
    },
    {
        name: "pink",
        background: "assets/lightPinkTexturedBackground.GIF",
        textColour: "#ffffff",
        linkColour: "#aa4f7c",
        mainBackgroundColour: "#f59aa9",
        sidebarBackgroundColour: "#d78eb3",
    },

]



function getVars() {
  const styles = getComputedStyle(r);
  const vars = {};
  for (let i = 0; i < styles.length; i++) {
    const name = styles[i];
    if (name.startsWith("--")) {
      vars[name] = styles.getPropertyValue(name).trim();
    }
  }
  console.log(vars);
  return vars;
}

function getRandomBackground() {
    const randomIndex = Math.floor(Math.random() * backgrounds.length);
    return backgrounds[randomIndex];
}

function setRandomBackground() {
    const randomBackground = getRandomBackground();
    r.style.setProperty("--background-image", `url(${randomBackground})`);
}

function setRandomTheme() {
    const randomIndex = Math.floor(Math.random() * themes.length);
    const theme = themes[randomIndex];
    r.style.setProperty("--background-image", `url(${theme.background})`);
    r.style.setProperty("--text-color", theme.textColour);
    r.style.setProperty("--link-color", theme.linkColour);
    r.style.setProperty("--content-background-color", theme.mainBackgroundColour);
    r.style.setProperty("--sidebar-background-color", theme.sidebarBackgroundColour);
}

setRandomTheme();